<?php
/**
 * @copyright	Copyright (c) 2015 ITB Company (http://itb-company.com/). All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die;

/**
 * ITB Company - Yandex Map Helper Class.
 *
 * @package		Joomla.Site
 * @subpakage	yamap.YandexMap
 */
class modYandexMapHelper {
	
}